var funcCalled = false
var drawn = generateDrawnNumbers()

function showBalance(){
    if (document.getElementById("balance1").style.opacity == 1) {
        document.getElementById("balance1").style.opacity = 0
    }
    else{
        document.getElementById("balance1").style.opacity = 1
    }   
}


var betAmount =  parseInt(document.getElementById("bett").textContent);

function decreaseBet() {
    if (betAmount > 1) {
        betAmount -= 1;
        document.getElementById("bett").textContent = betAmount;
    }
}

function increaseBet() {
    betAmount += 1;
    document.getElementById("bett").textContent = betAmount;
}


var k = 0
var userChoice = []
function changeColor(a){
    if (k <= 20){
        var b = document.getElementsByClassName("num")[a-1]
        b.style.backgroundColor = "rgba(4, 249, 87, 0.4)"
        if (!userChoice.includes(a)) {
            userChoice.push(a)
            k += 1
        }
    }
}


function generateDrawnNumbers() {
    let drawnNumbers = [];
    for (let i = 0; drawnNumbers.length < 20; i++) {
        if (!drawnNumbers.includes((Math.floor(Math.random() * 80) + 1))){
            drawnNumbers.push(Math.floor(Math.random() * 80) + 1);
        }
    }
    return drawnNumbers;
}

function checkWinning(ticket, drawnNumbers) {
    let numCorrect = 0;
    let listOfnums = [];
    for (let i = 0; i < ticket.length; i++) {
        if (drawnNumbers.includes(ticket[i])) {
            numCorrect++;
            var d = drawnNumbers.indexOf(ticket[i])
            //console.log(d)
            var d2 = document.getElementsByClassName("guess")[d]
            var c = document.getElementsByClassName("num")[ticket[i]-1]
            c.style.backgroundColor = "rgba(0, 89, 255, 0.438)"
            d2.style.backgroundColor = "rgba(0, 89, 255, 0.438)"
        }
        
    }
    return numCorrect;
}


var isFunctionCalled = false;
    
function play(us){
    if (!isFunctionCalled) {
        let drawnNumbers = generateDrawnNumbers();
        let guess = document.getElementsByClassName("guess")
        let betam = document.getElementById("betam")
        for(let i = 0; i < 20; i++){
            guess[i].innerHTML = "<p>" + drawnNumbers[i] + "</p>";
            guess[i].style.backgroundColor = "rgba(255, 0, 0, 0.329)"
        }
        let numCorrect = checkWinning(us, drawnNumbers);
        let winnings = betAmount * numCorrect;
        var bln = document.getElementById("baln")
        console.log(winnings, betAmount)
        if (numCorrect < 6) {
            betam.textContent = numCorrect;
            bln.textContent = parseInt(bln.textContent) - betAmount
        } else {
            betam.textContent = numCorrect;
            bln.textContent = parseInt(bln.textContent) + winnings
        }

        isFunctionCalled = true
        var stake = document.getElementsByClassName("stake")[0]
        stake.style.cursor = "not-allowed"
    }
}

function repeat(){
    location.reload(true)
}

function randm(){
    if(!funcCalled && !isFunctionCalled){        
        for(let i = 0; i < drawn.length; i++){
            var b = document.getElementsByClassName("num")[drawn[i]]
            b.style.backgroundColor = "rgba(4, 249, 87, 0.4)"
        }
        play(drawn)
        funcCalled = true

        var rnd = document.getElementsByClassName("randm")[0]
        rnd.style.cursor = "not-allowed"
    }
}